console.log("hello from sample-project");
function add(a, b) {
  return a + b;
}
module.exports = { add };
